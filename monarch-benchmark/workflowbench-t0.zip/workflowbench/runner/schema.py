"""The unified episode record (DESIGN.md §"Unified episode schema")."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field


class PhaseMetrics(BaseModel):
    turns: int = 0
    tool_calls: int = 0
    tokens_input: int | None = None
    tokens_output: int | None = None
    cost_usd: float | None = None
    wall_clock_s: float | None = None


class EpisodeRow(BaseModel):
    episode_id: str
    run_id: str
    suite: str = "workflowbench-synthetic@0.1"
    task_id: str
    contract_sha256: str | None = None
    arm: str                      # e.g. "oracle/scripted", "bare/cli/claude-code@x.y"
    mode: str = "synthetic"
    agent: str | None = None
    model: str | None = None
    trial: int = 0
    passed: bool
    assertions_passed: bool
    invariant_passed: bool
    invariant_declared: bool
    check_results: list[dict[str, Any]] = Field(default_factory=list)
    unexpected_changes: list[dict[str, Any]] = Field(default_factory=list)
    n_changes: int = 0
    phases: dict[str, PhaseMetrics] = Field(default_factory=dict)
    tool_calls: int = 0
    termination: str = "completed"   # completed|agent_error|infrastructure_error|timeout
    env_fingerprint: str | None = None
    artifacts_uri: str | None = None
    error: str | None = None
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: datetime | None = None
